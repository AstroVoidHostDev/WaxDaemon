/**
v1 WaxDaemon of AstroWax Panel (FIXED WS STABLE VERSION)
*/

process.env.dockerSocket = process.platform === "win32" ? "//./pipe/docker_engine" : "/var/run/docker.sock";

const express = require('express');
const Docker = require('dockerode');
const basicAuth = require('express-basic-auth');
const bodyParser = require('body-parser');
const CatLoggr = require('cat-loggr');
const WebSocket = require('ws');
const http = require('http');
const fs = require('node:fs');
const path = require('path');
const chalk = require('chalk');

const ascii = fs.readFileSync('./handlers/ascii.txt', 'utf8');
const { init } = require('./handlers/init.js');
const { seed } = require('./handlers/seed.js');
const { start } = require('./routes/InstanceFTP.js');
const { createDatabaseAndUser } = require('./routes/InstanceDB.js');
const config = require('./config.json');

const docker = new Docker({ socketPath: process.env.dockerSocket });

const app = express();
const server = http.createServer(app);
const log = new CatLoggr();

console.log(chalk.gray(ascii) + chalk.white(`version v${config.version}\n`));

init();
seed();

app.use(bodyParser.json());
app.use(basicAuth({
    users: { 'Skyport': config.key },
    challenge: true
}));

// =========================
// 🔥 WEBSOCKET (FIXED)
// =========================
function initializeWebSocketServer(server) {
    const wss = new WebSocket.Server({ server });

    function heartbeat() {
        this.isAlive = true;
    }

    wss.on('connection', (ws, req) => {
        ws.isAlive = true;
        ws.on('pong', heartbeat);

        let isAuthenticated = false;
        let lastAuthTime = 0;

        log.info("✅ WS Connected");

        ws.on('message', async (message) => {
            let msg = {};

            try {
                msg = JSON.parse(message);
            } catch {
                return ws.send('Invalid JSON');
            }

            // 🔐 AUTH
            if (msg.event === 'auth' && msg.args) {
                if (Date.now() - lastAuthTime < 1000) return;
                lastAuthTime = Date.now();

                if (msg.args[0] === config.key) {
                    isAuthenticated = true;
                    log.info('WS Auth success');
                    ws.send(JSON.stringify({ event: "auth_success" }));
                } else {
                    ws.close(1008, "Auth failed");
                }
                return;
            }

            if (!isAuthenticated) {
                return ws.close(1008, "Unauthorized");
            }

            // 🧠 Container logic
            const urlParts = req.url.split('/');
            const containerId = urlParts[2];

            if (!containerId) {
                return ws.close(1008, "No container ID");
            }

            const container = docker.getContainer(containerId);

            switch (msg.event) {
                case 'power:start':
                    await container.start().catch(()=>{});
                    break;
                case 'power:stop':
                    await container.kill().catch(()=>{});
                    break;
                case 'power:restart':
                    await container.restart().catch(()=>{});
                    break;
            }
        });

        ws.on('close', (code, reason) => {
            log.warn(`❌ WS Closed: ${code} ${reason}`);
        });

        ws.on('error', (err) => {
            log.error('WS Error:', err);
        });
    });

    // 🔥 HEARTBEAT LOOP (MOST IMPORTANT FIX)
    const interval = setInterval(() => {
        wss.clients.forEach((ws) => {
            if (ws.isAlive === false) {
                log.warn("💀 Killing dead socket");
                return ws.terminate();
            }

            ws.isAlive = false;
            ws.ping();
        });
    }, 30000);

    wss.on('close', () => clearInterval(interval));
}

// Start WS
initializeWebSocketServer(server);

// =========================
// BASIC ROUTES (UNCHANGED)
// =========================

app.get('/', async (req, res) => {
    try {
        const dockerInfo = await docker.info();
        const isDockerRunning = await docker.ping();

        res.json({
            version: config.version,
            online: true,
            docker: {
                status: isDockerRunning ? 'running' : 'stopped',
                info: dockerInfo
            }
        });
    } catch (err) {
        res.status(500).json({ error: 'Docker error' });
    }
});

// =========================
// START SERVER
// =========================
const port = config.port;

setTimeout(() => {
    server.listen(port, () => {
        log.info(`🚀 WaxDaemon running on ${port}`);
    });
}, 2000);